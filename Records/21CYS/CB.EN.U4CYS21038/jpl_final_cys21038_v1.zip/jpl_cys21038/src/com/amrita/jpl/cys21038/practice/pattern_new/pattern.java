package com.amrita.jpl.cys21038.practice.pattern_new;
/**
 * @author Madhav H
 */
public class pattern {
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
        }
        for (int i = 0; i < 6; i++) {
            System.out.println("==============================================");
        }
    }
}