package com.amrita.jpl.cys21038.practice.FileCreation;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
/**
 * @author Madhav H
 */
public class File_create {
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
         try {
             File myFile  = new File("C:\\Users\\Hari\\OneDrive - Amrita Vishwa Vidyapeetham\\Desktop\\AMRITA\\SEM 4\\Java pgmming\\Original\\src\\com\\amrita\\jpl\\cys21038\\practice\\FileCreation");
              Scanner myScan = new Scanner(myFile);
              while(myScan.hasNextLine()){
                  String d = myScan.nextLine();
                  System.out.println(d);
              }
        }
        catch (IOException e) {
            System.out.println("[ERROR] Input Output Exception");
            e.printStackTrace();
        }
    }
}