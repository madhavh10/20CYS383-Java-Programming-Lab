#include <iostream>
using namespace std;
class A
{float d;
   public:
    A()
{ cout<<"Constructor of class A\n";
}
};
 
class B: public A
{ int a = 15;
    public:
	B(){
		cout<<"Constructor of class B\n";
}
};
int main()
{
	B b;
	return 0;
}

