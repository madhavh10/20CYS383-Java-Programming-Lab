#include<iostream>
//using namespace std; //A namespace is a declarative region that provides a scope to the identifiers (the names of types, functions, variables, etc) inside it
int main()
{
	int a;
	std::cin>>a; // Here std is called as scope resolution operator
	std::cout<<a;
	return 0;
}
