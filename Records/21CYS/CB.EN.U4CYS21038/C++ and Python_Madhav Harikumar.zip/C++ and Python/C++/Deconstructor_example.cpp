#include<iostream>
using namespace std;
class HelloWorld
{
public:
//default Constructor
	HelloWorld()
	{
		cout<<"Constructor is called"<<endl;
	}
//Destructor
	~HelloWorld()
	{
		cout<<"Destructor is called"<<endl;
	}
//Member function
	void display()
	{
		cout<<"Hello World!"<<endl;
	}
};

int main()
{
	HelloWorld x;
	x.display();
}
