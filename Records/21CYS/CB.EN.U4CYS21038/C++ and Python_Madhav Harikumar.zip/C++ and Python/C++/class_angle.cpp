#include<iostream>
using namespace std;
class angle
{
	private:
		int d;
		float m;
		char dir;
	public:
		
};
