#include<iostream>
using namespace std;

class Base
{
	public:
		int x,y;
		int add(int x, int y)
		{
			int g= x*y;
			return g;
		}
};
int main()
{
	Base d;
	int r=d.add(5,6);
	cout<<r<<endl;
}
