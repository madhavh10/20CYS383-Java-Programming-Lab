//DYNAMIC MEMORY ALLOCATION IN C++
#include<iostream>
using namespace std;
class Student
{
	int age;
	public:
		Student()
		{
			age=18;
		}
		void getage()
		{
			cout<<age<<endl;
		}
};
int main()
{
	Student *x = new Student;
	x->getage();
}
