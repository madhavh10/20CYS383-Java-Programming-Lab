#include<iostream>
using namespace std;

class Base
{
	protected:
		int x=10;
};

class Derived : protected Base{
	public:
		void print()
		{
			cout<< x <<endl;
		}
};

int main()
{
	Derived f;
	f.print();
	return 0;
}
