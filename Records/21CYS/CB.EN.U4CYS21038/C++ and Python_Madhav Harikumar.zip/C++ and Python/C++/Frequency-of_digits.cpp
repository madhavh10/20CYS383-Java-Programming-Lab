#include <iostream>
using namespace std;
int frequency(int n, int d)
{
	int c = 0;
	while (n > 0){
		if (n % 10 == d)
			c++;
		n = n / 10;
	}
	
	return c;
}

int main()
{
	int N,D;
	cin>>N>>D;
	cout<<frequency(N,D);

	return 0;
}

