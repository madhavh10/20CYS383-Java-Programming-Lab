#include<iostream>
using namespace std;
int main()
{
	int num,temp,sum=0,r=0,flag=0;
	cin>>num;
	temp=num;
	while(num>0)
	{
		r=num%10;
		sum = (sum*10)+r;
		num=num/10;
	}
	//cout<<r<<endl;
	if(sum==temp)
	{
		cout<<"Palindrome";
	}
	else
	{
		cout<<"Not palindrome";
	}
}
