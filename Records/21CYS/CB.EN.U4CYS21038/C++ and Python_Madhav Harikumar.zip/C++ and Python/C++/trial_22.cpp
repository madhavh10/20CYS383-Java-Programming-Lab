#include<iostream>
class good
{
int a=5;
int b=4;
public:
void get()
{
cin>>a>>b;
}
void put()
{
cout<<a<<" "<<b;
}
};

int main()
{
good g;
g.get();
g.put();
return 0;
}
