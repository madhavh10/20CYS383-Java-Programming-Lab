#include<iostream>
using namespace std;

class complex
{
	private:
		float real,imagine;
	public:
		void getData();
		void putData();
		void sum(complex A,complex B);
};

void complex::getData()
{
	cin>>real;
	cin>>imagine;
}
void complex::putData()
{
	if(imagine>=0)
	{
		cout<<real<<"+"<<imagine<<"i";
	}
	else
	{
		cout<<real<<imagine<<"i";
	}
}
void complex::sum(complex x, complex y)
{
	real = x.real+y.real;
	imagine = x.imagine+y.imagine;
}
int main()
{
	complex X,Y,Z;
	X.getData();
	Y.getData();
	Z.sum(X,Y);
	Z.putData();
	return 0;
}

}
