#include<iostream>
using namespace std;

int main()
{
    int n1,n2,hcf;
    cin>>n1;
    cin>>n2;
    int temp= n1*n2;
    for(int i=1;i<=temp;i++)
    {
        if((i%n1==0)&&(i%n2==0))
        {
            lcm = i;
			break;
        }
    }
    cout<<lcm;
}