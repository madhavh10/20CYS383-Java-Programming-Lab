#include<iostream>
using namespace std;
class Base
{
	private:
		int x;
	protected:
		int y;
	public:
		int z;
		Base()
		{
			x=10;
			y=20;
			z=30;
		}
};
class D1 : public Base
{
	private:
		int a;
	protected:
		int b;
	public:
		int c;
		D1()
		{
			a=10;
			b=20;
			c=30;
		}
};
class D2 : public Base
{
	private:
		int p;
	protected:
		int q;
	public:
		int r;
		D2()
		{
			p=10;
			q=20;
			r=30;
		}
};

class D_sub : public D1,public D2
{
	public:
	D_sub()
	{
		cout<< D1::c << endl <<D2::r<<endl;	//we have to use resolution operator for hybrid inheritance or else the computer won't know which to inherit
	}
};
int main()
{
	D_sub obj;
	
}
