#include<iostream>
using namespace std;
class Array_details
{
	public:
		int A[10];
	public:
		int Read_array()
		{
			for(int i=0;i<10;i++)
			{
				cin>>A[i];
			}
		}
};
class Functions : public Array_details
{
	public:
	int s_ort()
	{
		Read_array();
		for(int x=0;x<10;x++)
		{
			for(int j=0;j<11-x;j++)
			{
				int temp=A[j];
				A[j]=A[j+1];
				A[j+1]=temp;
			}
		}
		for(int x=0;x<10;x++)
		{
			cout<<A[x]<<endl;
		}
		return 0;
	}
};
int main()
{
	Functions g;
	g.s_ort();
}
