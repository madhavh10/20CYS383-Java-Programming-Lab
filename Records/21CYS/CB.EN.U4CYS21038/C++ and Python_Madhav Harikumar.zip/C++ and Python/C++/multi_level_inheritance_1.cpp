#include <iostream>
using namespace std;
class parent
{
        private:
        int x=10000;
        public:
        int y=2000;
        protected:
        int z=3000;
 
};
 
class child_1:protected parent
 
{
        protected:
        int a=4000;
 
};
 
class child_1_1:protected child_1
{
        public:
        int b=5000;
        void display()
        {
                cout << z << endl;
        }
 
};
 
int main(){
 
    child_1_1 c;
    c.display();
    return 0;
};

