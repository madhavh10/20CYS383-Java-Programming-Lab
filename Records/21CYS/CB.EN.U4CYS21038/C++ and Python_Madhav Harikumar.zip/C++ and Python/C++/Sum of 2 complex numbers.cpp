#include<iostream>
using namespace std;
class complex{
    private:
    int real;
    int imagine;
    public:
    void getdata();
    void sum(complex x,complex y);
    
    
};
void complex::getdata(){
    cout<<"enter the real value";
    cin>>real;
    cout<<"enter the imaginary value";
    cin>>imagine;
}
void complex::sum(complex num1,complex num2){
    real=num1.real+num2.real;
    imagine=num1.imagine+num2.imagine;
    if (imagine>=0){
        cout<<real<<"+"<<imagine<<"i";
    }
    else {
        cout<<real<<imagine<<"i";
    }
    
}
int main()
{
    complex X,Y,Z;
    X.getdata();
    Y.getdata();
    Z.sum(X,Y);
    return 0;
};