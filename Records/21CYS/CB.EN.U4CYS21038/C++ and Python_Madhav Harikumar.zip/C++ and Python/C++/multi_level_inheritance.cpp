#include<iostream>
using namespace std;

//BASE CLASS
class base
{
	public:
		int x;
		void getdata()
		{
			cin >> x;
		}
	protected:
		int a;
		void getdata1()
		{
			cin >> a;
		}
};

class derive1 : public base
{
	public:
		int y;
		void readdata()
		{
			cin >> y;
		}
	protected:
		int b;
		void readdata1()
		{
			cin >> b;
		}
};

class derive2 : public derive1
{
	private:
		int z;
	public:
		void indata()
		{
			cin >> z;
		}
		void product()
		{
			cout<<"Product= " << x*y*z;
		}
	protected:
		void product1()
		{
			cout<<"Product= " << a*b*z;
		}
};

//MAIN
int main()
{
	derive2 a;
	a.getdata();
	//a.getdata1();
	a.readdata();
	//a.readdata1();
	a.indata();
	a.product();
	//a.product1();
	return 0;
}
