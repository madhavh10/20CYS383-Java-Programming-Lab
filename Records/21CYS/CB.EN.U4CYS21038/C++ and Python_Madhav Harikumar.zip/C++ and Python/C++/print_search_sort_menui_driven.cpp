/*
#include<iostream>
using namespace std;
class sort
{
	private:
		int n,A[10],i,j,temp;
	public:
		int bubble(int A[],int n);
};
class search
{
	private:
		int n,A[10],i,t;
	public:
		int search_1(int A[],int n,int t)
		{
			for(i=0;i<n;i++)
			{
				if(t==A[i])
				{
					cout<< i << endl;
					break;
				}
			}
		}
		
};
int sort :: bubble(int A[],int n)
{
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(A[j]>A[j+1])
			{
				temp = A[j];
				A[j]=A[j+1];
				A[j+1]=temp;
			}
		}
	}
	for(i=0;i<n;i++)
	{
		cout<<A[i]<<endl;
	}
}
int main()
{
	int num,i,ch,m;
	int B[20];
	cin>>num;
	for(i=0;i<num;i++)
	{
		cin>>B[i];	
	}
	cin>>ch;
	if(ch==1)
	{
		for(i=0;i<num;i++)
		{
			cout <<B[i]<<endl;	
		}
	}
	if(ch==2)
	{
		sort f;
		f.bubble(B,num);
	}
	if(ch==3)
	{
		cin>>m;
		search z;
		z.search_1(B,num,m);
	}
	return 0;
}
*/#include<iostream>
using namespace std;

class Sort{

protected:
int a[10];

public:
int n;
void read()
{   //@start-editable@

    for(int i=0;i<n;i++)
	{
		cin>>a[i];	
	}
 
 //@end-editable@

}
void print()
{   //@start-editable@

    for(int i=0;i<n;i++)
    {
        cout<<" "<<a[i];
    }

 
 //@end-editable@

}

void selectionSort() {
 //@start-editable@

    int temp;
    for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				temp = a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<" "<<a[i];
	}
 
 
 
 //@end-editable@
}
};

class binary_search : public Sort
{
  public:
  int num;
  int binarySearch(int startindex, int endindex) {
    //@start-editable@
    cin>>num;
    int i,ix;
    for(i=0;i<n;i++)
    {
    	if(a[i]==num)
    	{
    		ix = i ;
		}
	}
	return ix;
 
 
 //@end-editable@
}
};


int main() {
  binary_search BS;
  int choice,index;
  cin>>BS.n;
  BS.read();
  cin>>choice;
  if(choice==1)
  {
   //@start-editable@

   BS.print();
 
 
 //@end-editable@

  }
  if(choice==2)
  {
   //@start-editable@

    BS.selectionSort();
 
 
 
 //@end-editable@

  }
  if(choice==3)
  {
   //@start-editable@


    index=BS.binarySearch(0,BS.n);
     
 
 
 
 //@end-editable@

  if(index == -1){
      cout<< BS.num <<" is not present in the array";
   }else{
      cout<< BS.num <<" is present at index "<< index + 1 <<" in the Sorted array A";
   }
  }
return 0;
}

