#include <iostream>
using namespace std;

#include<iostream>
class A{
  private:
    int p1 = 11;

  protected:
    int p2 = 22;

  public:
    int p3 = 33;

    // function to access private member
    int getpriv() 
	{
      return p1;
    }
};

class B : public A {
  public:
    int getPr() 
	{
      return p2;
    }
};

int main() {
  B obj;
  cout << "Private = " << obj.getpriv() << endl;
  cout << "Protected = " << obj.getProt() << endl;
  cout << "Public = " << obj.p3 << endl;
  return 0;
}

