#include <iostream>
using namespace std;
 
class Inventory
{
private:
    int price, minimum_order, order_amount=0, reorder_point, stock;
    string item_name, ItemID;
 
public:
    Inventory()
    {
 
        cin >> item_name;
        cin >> ItemID;
        cin >> price;
        cin >> stock;
        cin >> reorder_point;
        cin >> minimum_order;
        if (stock < reorder_point)
        {
            order_amount = reorder_point + minimum_order - stock + 1;
            
        }
    }
 
    int order()
    {
        if (order_amount > 0)
        {
            cout << item_name << endl<< order_amount << endl;
            return 1;
        }
        else{
            return 0;
        }
 
    }
};
 
int main()
{
    int N;
    int d=1;
    cin >> N;
    Inventory A[N];
    int c=0;
    for (int i = 0; i < N; i++)
    {
        
        d = A[i].order();
        c = c + d;
    }
    if (c == 0){
        cout << "All items are available";
    }
    return 0;
}
