#include<iostream>
using namespace std;
int main()
{
    int x;
    char z;
    float y;
    double t;
    bool m;
    cout<<"Size of char:"<<sizeof(z)<<endl;
    cout<<"Size of int:"<<sizeof(x)<<endl;
    cout<<"Size of float:"<<sizeof(y)<<endl;
    cout<<"Size of double:"<<sizeof(t)<<endl;
    cout<<"Size of bool:"<<sizeof(m)<<endl;
    return 0;
}
