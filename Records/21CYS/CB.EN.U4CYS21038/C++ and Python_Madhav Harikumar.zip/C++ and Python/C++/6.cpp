//Simple Example of Polymorphism
#include <iostream>
using namespace std;
 
 
void add(int a, int b)
{
  cout << "sum = " << (a + b);
}
 
void add(double a, double b)
{
    cout << endl << "sum = " << (a + b);
}
 

int main()
{
    add(10, 2);
    add(5.3, 6.2);
 
    return 0;
}
//Overloading will happend during compile time --> also called as early binding
//Overriding will happen during runtime --> also called as late binding
