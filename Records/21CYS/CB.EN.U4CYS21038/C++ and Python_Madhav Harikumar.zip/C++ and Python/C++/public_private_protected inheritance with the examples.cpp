#include <iostream>
using namespace std;
 
class A {
    private:
    	int z=500;
    public:
    	int x;
    protected:
    	int y;
    	int getPVT() 
		{
      		return z;
    	}
};
class B : public A { // public inheritannce.
    // x stays public.
    // y stays protected.
    // z is not accessiable in this class.
    public:
    void get_y() {
        cout  << getPVT();
    }
};
 
class C : private A { // private inheritannce.
    // x becomes private.
    // y becomes private.
    // z is not accessiable in this class.
}; 
 
class D : protected A { // protect inheritance.
    // x becomes protected.(which means private)
    // y becomes protected.(which means private)
    // z is not accessiable in this class.
}; 
 
int main() {
    //B qwe;
    //C asd;
    //D zxc;
    //qwe.get_y();
    //asd.getPVT();
    //zxc.getPVT();
}

