#include<iostream>
using namespace std;
class parent1 //Base class 1
{
	private:
		int Ab;
	protected:
		int Ac;
	public:
		int Aa;
		parent1()
		{
			Ab=10;
			Ac=20;
			Aa=30;
		}
		void display1()
		{
			cout<<"The value of private variable Ab is:"<<Ab<<endl;
			cout<<"The value of protected variable Ac is:"<<Ac<<endl;
			cout<<"The value of public variable Aa is:"<<Aa<<endl;
		}
};
class parent2 //Base class 2
{
	private:
		int Bb;
	protected:
		int Bc;
	public:
		int Ba;
		parent2()
		{
			Bb=40;
			Bc=50;
			Ba=60;
		}
		void display2()
		{
			cout<<"The value of private variable Bb is:"<<Bb<<endl;
			cout<<"The value of protected variable Bc is:"<<Bc<<endl;
			cout<<"The value of public variable Ba is:"<<Ba<<endl;
		}
};
class parent3 //Base class 3
{
	private:
		int Cb;
	protected:
		int Cc;
	public:
		int Ca;
		parent3()
		{
			Cb=70;
			Cc=80;
			Ca=90;
		}
		void display3()
		{
			cout<<"The value of private variable Cb is:"<<Cb<<endl;
			cout<<"The value of protected variable Cc is:"<<Cc<<endl;
			cout<<"The value of public variable Ca is:"<<Ca<<endl;
		}
};
class child : public parent1,protected parent2,private parent3
{
	public:
		child()
		{
			cout<<"Sum is:"<<Ac+Aa+Bc+Ba+Cc+Ca<<endl;
		}
};

int main()
{
	parent1 obj1;
	obj1.display1();
	parent2 obj2;
	obj2.display2();
	parent3 obj3;
	obj3.display3();
	child G;
	return 0;
}

