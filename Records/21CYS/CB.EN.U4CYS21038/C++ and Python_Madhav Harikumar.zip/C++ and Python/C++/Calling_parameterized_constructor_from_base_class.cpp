#include<iostream>
using namespace std;
class Base
{
	int x;
	public:
		Base()
		{
			cout<<"Base \n";
		}
		Base(int i)
		{
			cout<<"Base parameterized constructor"<<i<<"\n";
		}
		
};
class Derived : public Base //Calling both default and parameterized 
{
	int y;
	public:
		Derived():Base(30) // calling the default base constructor
		{
			cout<<"Derived \n";
		}
		Derived(int i):Base(20)
		{
			cout<<"Derived parameterized constructor"<<i<<"\n";
		}
};
int main()
{
	Derived x;
	/*
	It will go to the derived first, since derived does not have a constructor, it will call "Derived():Base(30)" and in that 
	"Base(30)" means it will go to the base class and since there is a parameter, it will go to Base(int i) in base class
	*/
	Derived y(40);
	/*
	It will go to derived first, since there is a parameter given in the derived at main, it will call "Derived(int i):Base(20)" 
	and in that "Base(20)" means it will go to base class and since there is a parameter, it will go to Base(int i) in base class
	*/
	Base r;
	/*It will go to Base() in the Base class and print whatever is given in the base constructor*/
	Base j(50);
	/*It will go to Base class and inside that it will got to Base(int i) and print whatever is given in that constructor*/
}

