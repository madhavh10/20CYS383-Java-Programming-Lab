#include<iostream>
int main()
{
	int n,i,j;
	std::cout<<"Enter a number:";
	std::cin>>n;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<i+1;j++)
		{
			std::cout<<j;
		}
		std::cout<<"\n";
	}
	return 0;
}
