#include<iostream>
using namespace std;

int main()
{
    int n1,n2,hcf;
    cin>>n1;
    cin>>n2;
    int temp= min(n1,n2);
    for(int i=1;i<=temp;i++)
    {
        if((n1%i==0)&&(n2%i==0))
        {
            hcf = i;
        }
    }
    cout<<hcf;
}