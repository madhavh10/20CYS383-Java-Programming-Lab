/* To find power of a number using loop */
#include <iostream>
using namespace std;
int main()
{
    int bs, ex, num=1,i;
    cout << " Enter the base : ";
    cin >> bs;
    cout << " Enter the exponent: ";
	cin>>ex;
	
    for (i = 1; i <=ex; i++) 
    {
       num=num*bs;
    }
	cout <<bs<<" ^ "<<ex<<" = "<<num<<endl ;
}
