#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class mark{
    public:
    int roll;
    string name;
    //void print(){
      //  cout<<roll<<" "<<name;
    //}
};
class READ:public mark{
    public:
    void READ1()
    {
        cin>>roll;
        cin>>name;
    }
};
class put:public READ{
    public:
     void put1(){
        cout<<roll<<" "<<name;
    }
};
int main()
{
    

    put obj2;
    obj2.READ1();
    obj2.put1();
    
    
    
    // obj1.read();
    // obj2.putdata();
    return 0;
};
