#include<iostream>
using namespace std;

class Base
{
	public:
		int x=10;
	protected:
		int y = 20;	
};

class Derived : protected Base
{
	/*
protected : int x =10; y =20;	
	*/
	public:
	void print()
	{
		cout<< x << " "<< y <<endl;
	}
};

class exp : private Base {
		/*private:
		int x = 10;
		int y = 20;	*/
};
class Derived1 : private Derived
{
	private:
		/*
		int x=10; y = 20;
		void print()
	{
		cout<< x << " "<< y <<endl;
	}*/
	public:
		void print_1(){
			print();
			cout << endl << x << " " << y << endl;
		}
		void display();
		
};

class B : public Derived1 {
	public:
		/*void print_1(){
			print();
			cout << endl << x << " " << y << endl;
		}
		void display();
		}*/
		
};
void Derived1 :: display() {
	cout << "It'works.."<<endl;
}

int main()
{
	Derived q;
	Derived1 r;
	B t;
	q.print();
	r.print_1();
	r.display();
	t.print_1();
	return 0;
}
