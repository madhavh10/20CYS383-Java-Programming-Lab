#include <iostream>
using namespace std;
int main ()
{
	int i;
	for(i=97;i<123;i++)
	{
		cout<<char(i)<<" "<<i<<endl;
	}
}
