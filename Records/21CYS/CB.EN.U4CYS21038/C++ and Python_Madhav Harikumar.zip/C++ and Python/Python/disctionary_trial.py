d={1:"a",2:"b",3:"c"}
print(list(d.values()))
d[3]="x"
print(d)
