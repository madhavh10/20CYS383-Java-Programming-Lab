print("Hello world!!")
print("Why yaswanth why")