x=10
y=20
print(eval('x!=y'))
y=10
print(eval(f'{x}!={y}')) # since the format is string, we have to use the format symbol
