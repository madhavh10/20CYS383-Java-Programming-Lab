import array
arr=array.array('i',[1,2,3,4,5,6,5,4])
print("The array is:",end="")
for i in range(0,6):
    print(arr[i],end="")
print()
arr.reverse()#To reverse an array
print(arr)
x=arr.count(5)#To count the occurence of an element in the array
print(x)
array1=array.array('i',[0,1])
array2=array.array('i',[2,3,4,5])
array1.extend(array2)#To extend the first array by adding the next array to it 
print(array1)
L=arr.tolist()#Converting array to list
print(L)
