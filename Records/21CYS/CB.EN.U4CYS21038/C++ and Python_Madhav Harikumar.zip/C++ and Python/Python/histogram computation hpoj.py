a=input()
d={}
for i in a:
    for j in i:
        if j in d:
            d[j]+=1
        else:
            d[j]=1
print(d)
