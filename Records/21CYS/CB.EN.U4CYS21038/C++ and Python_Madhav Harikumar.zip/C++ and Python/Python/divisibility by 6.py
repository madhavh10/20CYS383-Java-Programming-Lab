n=int(input())
if(n%6==0):
    print("Number is divisible by 6\n")
else:
    print("Number is not divisible by 6")
