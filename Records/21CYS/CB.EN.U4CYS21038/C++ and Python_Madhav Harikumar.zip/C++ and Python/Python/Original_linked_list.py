'''
while(temp) -> this will go after the last element, but it will execute for all the elements
while(temp.next) -> will go upto last element, but it will not execute last element

'''
class node:
    def __init__(self,data):
        self.data = data
        self.next = None
class linkedlist:
    def __init__(self):
        self.head = None
    def printll(self):
        temp = self.head
        while(temp):
            print(temp.data,end="->")
            temp=temp.next
    def addEnd(self,i):
        temp = self.head
        while(temp.next):
            temp = temp.next
        op = node(i)
        temp.next = op
    def addbegin(self,i):
        temp=self.head
        op=node(i)
        op.next=temp
        self.head=op
    def removebegin(self):
        temp=self.head
        temp2=temp.next
        self.head = temp2
        temp.next=None
        temp.data=None
    def removeEnd(self):
        temp = self.head
        while(temp.next.next):
            temp = temp.next
        temp.next = None
    def insert(self,index,i):
        if(index==0):
            ll.addbegin(i)
        else:
            temp = self.head
            d=0
            while(temp.next):
                if(index==d):
                    break
                d=d+1
                temp = temp.next
            l = node(i)
            temp2 = temp.next
            temp.next = l
            l.next = temp2
    def size1(self):
        temp = self.head
        c=0
        while(temp.next):
            c=c+1
            temp=temp.next
        print("Size:",c)
        return c

    def remove(self,i):
        if(i==0):
            ll.removebegin()
        else:
            temp=self.head
            d=0
            while(temp): #this will go upto n elements including the nth element for the inside
                if(d==i-1):
                    break
                d=d+1
                temp=temp.next
            temp.next=temp.next.next
    def reverse(self):
        prev=None
        temp=self.head
        while(temp):
            temp1=temp.next
            temp.next = prev
            prev=temp
            temp=temp1
        self.head=prev

    def swap_nodes(self, a, b):
        # Initialize current, previous and temp pointers
        current1 = self.head
        previous1 = None
        current2 = self.head
        previous2 = None
        # traverse the list to find the first node
        while current1.data != a:
            previous1 = current1
            current1 = current1.next
        # traverse the list to find the second node
        while current2.data != b:
            previous2 = current2
            current2 = current2.next
        # Edge case: If either of the nodes is not present in the linked list
        if current1 == None or current2 == None:
            return
        # If node1 is not the head of the linked list
        if previous1 != None:
            previous1.next = current2
        else:
            # If node1 is the head of the linked list
            self.head = current2
        # If node2 is not the head of the linked list
        if previous2 != None:
            previous2.next = current1
        else:
            # If node2 is the head of the linked list
            self.head = current1
        current1.next, current2.next = current2.next, current1.next

ll = linkedlist() 
ll.head = node(13)
second = node(31)
third = node(57)

ll.head.next = second
second.next = third

ll.addEnd(25) #13 31 57 25
ll.addbegin(12)# 12 13 31 57 25
ll.removebegin()#13 31 57 25
ll.removeEnd()#13 31 57 
ll.insert(0,96)#96 13 31 57 
ll.remove(ll.size1()-1)#96 13 57
ll.swap_nodes(13,57)
ll.printll()
ll.size1() #3
ll.reverse()
ll.printll()#57 13 96
           

                
        
        
        
