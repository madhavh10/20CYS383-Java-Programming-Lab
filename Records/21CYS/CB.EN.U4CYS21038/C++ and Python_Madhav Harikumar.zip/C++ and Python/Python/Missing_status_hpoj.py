def findMissing(N,stringOfRolls):
    missingStatus = "All Present"
    L=[]
    x=stringOfRolls.split()
    L1=[int(b) for b in x]
    for i in range(1,N+1):
        L.append(i)
    for j in L:
        if j not in L1:
            missingStatus = j
    return missingStatus


N=int(input())
stringOfRolls=input()
missingRoll=findMissing(N,stringOfRolls)
print(missingRoll)
