'''
Class and Objects
1) basic working of a class
class MyClass:
    x=5
p1=MyClass()
print(p1.x)

'''
'''
2) Class with the object and accessing
class Person:
    #__init__() -->to assign values to object properties, or other operations that are necessary to do when the object is being created
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def yo(self):
        print(self.name)
        print(self.age)
p1= Person('John',45)
p1.yo()
'''
'''
3) Modifying the class object and deleting the object

class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def yo(self):
        print(self.name)
        print(self.age)
p1 = Person('Sudhir',65)
p1.yo()
p1.name='yaswanth'
p1.yo()
del p1.age
print(p1.age)
'''
'''
4) Additional functions
class Person:
    #__init__() -->to assign values to object properties, or other operations that are necessary to do when the object is being created
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def yo(self):
        print(self.name)
        print(self.age)
p1= Person('John',45)
print(getattr(p1,'name'))#returns the value
print(hasattr(p1,'age'))#return boolean value
setattr(p1,'name','yaswanth')#will update the value
p1.yo()
print(setattr(p1,'name','Deepthi Y'))#will return none
print(delattr(p1,'age'))#will return none
#p1.yo()
'''

'''
5) Private Access Specifier
Adding a prefix __(double underscore) to a variable name makes it private

class Employee:
# constructor
    def __init__(self, name, sal):
        self.name = name
        self.__sal = sal
emp = Employee("Ironman", 999000)
print(emp._sal)
'''
'''
6) Protected Access Specifier
Adding a prefix _(single underscore) to a variable name makes it protected
class Employee:
# constructor
    def __init__(self, name, sal):
        self._name = name
        self._sal = sal
emp = Employee("Ironman", 999000)
print(emp._name)
print(emp._sal)
'''
'''
7) Deconstructor in Python
class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def myfunc(self):
        print("Hello my name is "+self.name)
    def __del__(self):
        print("Class and the objects are destroyed after program execution")
p1 = Person("John",36)
p1.myfunc()# this will print the function and also will delete the attributes of the class after program execution
'''
'''
8) Method Overloading
This means that if you create 2 functions using the same function name, the one which we created new, i.e. the latest
function which is been created will be the new function as default
def product(a, b, c):
    p = a * b*c
    print(p)
def product(a, b):
    p = a * b
    print(p)
product(4, 5)
product(4, 5, 5)


In this case, product(a,b) will be the default function, so the first print statement will work, but the second print statement
will show an error

class Compute:
    def area(self,x=None,y=None):
        if x!=None and y!=None:
            return x*y
        elif x!=None:
            return x*x
        elif y!=None:
            return y*y
        else:
            return 0
a=Compute()
print("Area is:",a.area())
print("Area is:",a.area(None,4))
print("Area is:",a.area(5,None))
print("Area is:",a.area(3,5))
'''
'''
9) Operator Overloading

class Point:
    def __init__(self,x=0,y=0):
        self.x=x
        self.y=y
    def __add__(a,b):
        return (a.x+b.x,a.y+b.y)
    def __mul__(a,b):
        return (a.x*b.x,a.y*b.y)
    def __pow__(a,b):
        return (a.x**b.x,a.y**b.y)
p1=Point(2,3)
p2=Point(3,4)
p3=p1+p2
print(p3)
print(p1*p2)
print(p1**p2)
'''
'''
10) Array input in Python
import array
arr=array.array('i',[1,2,3,4,5,6])
print("The array is:",end="")
for i in range(0,6):
    print(arr[i],end="")
print()
'''
'''
11) Array and set
import array
import operator
arr=array.array('i',[10,10,4,5,6,7,5,4,8])
L=arr.tolist()
L1=[]
x=0
for i in set(L): #set returns only unique elements
    x=operator.countOf(L,i)
    print(i,"=",x)
'''
'''
12)Python program to check if the number is an Armstrong number or not

# take input from the user
num = int(input("Enter a number: "))

# initialize sum
sum = 0

# find the sum of the cube of each digit
temp = num
while temp > 0:
   digit = temp % 10
   sum += digit ** 3
   temp //= 10

# display the result
if num == sum:
   print(num,"is an Armstrong number")
else:
   print(num,"is not an Armstrong number")
'''
'''
13) Prime numbers in an interval
a=int(input())
b=int(input())
for i in range(a,b+1):
    if i>1:
        for j in range(2,i):
            if(i%j==0):
                break
        else:
            print(i)
'''
'''
14)Fibonacci series
a=0
b=1
c=1
print(a,"\t",end="")
print(b,"\t",end="")
print(c,"\t",end="")
x=a+b+c
while(x<100):
    print(x,"\t",end="")
    a=b
    b=c
    c=x
    x=a+b+c
'''
'''
15)Set Operations
thisset = {"apple", "banana", "cherry"}
thisset.add("orange")#To add an element in set
print(thisset)

thisset = {"apple", "banana", "cherry"}
thisset.update(["orange", "mango", "grapes"])#to add multiple elements in a set we use update function
print(thisset)
'''
'''
16)Dictioanry and operations
D = {1: 'Geeks', 2: 'For', 3: 'Geeks'}
print("\nDictionary with the use of Integer Keys: ")
print(D) #this will print {1: 'Geeks', 2: 'For', 3: 'Geeks'}

Dict = dict({1: 'Geeks', 2: 'For', 3:'Geeks'})#using dict method
print("\nDictionary with the use of dict(): ")
print(Dict)#{1: 'Geeks', 2: 'For', 3:'Geeks'}

Dict = dict([(1, 'Geeks'), (2, 'For')])
print("\nDictionary with each item as a pair: ")
print(Dict)#{1: 'Geeks', 2: 'For'}

#Adding elements into dictionary
Dict={} 
Dict[0] = 'Geeks'
Dict[2] = 'For'
Dict[3] = 1
print("\nDictionary after adding 3 elements: ")
print(Dict)

# Creating a Dictionary
Dict = {'Dict1': {1: 'Geeks'},'Dict2': {'Name': 'For'}}
# Accessing element using key
print(Dict['Dict1'])
print(Dict['Dict1'][1])
print(Dict['Dict2']['Name'])

# Deleting a Key from
# Nested Dictionary
Dict = { 5 : 'Welcome', 6 : 'To', 7 : 'Geeks',
'A' : {1 : 'Geeks', 2 : 'For', 3 : 'Geeks'},
'B' : {1 : 'Geeks', 2 : 'Life'}}
print("Initial Dictionary: ")
print(Dict)
del Dict['A'][2]
print("\nDeleting a key from Nested Dictionary: ")
print(Dict)

#sum of values in dictionary
dict = {'a': 100, 'b': 200, 'c': 300}
print(sum(dict.values()))

'''
'''
17) Factorial 
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)
n=int(input("Input a number to compute the factiorial : "))
print(factorial(n))
'''
'''
18) Highly composite numbers in python
def get_divisors(number_range):
  divisor_list = []
  divisor_list2 = []
  for number in range(1,number_range+1):
    for e in range(1,number_range+1):
      if number % e == 0:
        divisor_list2.append(e)
    divisor_list.append(divisor_list2)
    divisor_list2 = []
  return divisor_list

def get_highly_composite_number(number_range):
  divisor_list = get_divisors(number_range)
  highly_composite_number_list = []
  number_of_divisor_list = []
  number_of_divisor_list2 = []
  number_of_divisor_list3 = []
  tracker = 0
  for e in divisor_list:
    number_of_divisor_list.append(len(e))
    number_of_divisor_list2.append(max(number_of_divisor_list))
  for e in number_of_divisor_list2:
    number_of_divisor_list3.append(e)
    if number_of_divisor_list3[tracker] == max(number_of_divisor_list3) and number_of_divisor_list3.count(number_of_divisor_list3[tracker]) == 1:
      highly_composite_number_list.append(tracker+1)
      tracker += 1
    else:
      tracker += 1
  return highly_composite_number_list
'''
'''
19) Basic Stack 
class MyStack:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return not self.items

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def peek(self):
        return self.items[-1]

    def size(self):
        return len(self.items)

    def print_stack(self):
        for i in self:
            print(i)
stack=MyStack()
stack.push(1)
stack.push(2)
stack.push(3)
stack.push(4)
stack.push(5)
stack.print()
'''

'''
20) Linked list implementation
class Node:
    def __init__(self,data):
        self.data=data
        self.next = None
class Linked_list:
    def __init__(self):
        self.head=None
    def print_list(self):
        while self.head is not None:
            print(self.head.data,end="->")
            self.head=self.head.next
    def prepend(self,new):
        new_node=Node(new)
        new_node.next = self.head
        self.head=new_node
    def append(self,new):
        new_node=Node(new)
        if self.head is None:
            self.head = new_node
            return
        last = self.head
        while(last.next):
            last=last.next
        last.next=new_node
    def insertbtw(self,middle_node,new):
        if middle_node is None:
            print("The mentioned node is not present")
            return
        new_node = Node(new)
        new_node.next = middle_node.next
        middle_node.next = new_node
    def delnode(self,nw):
        head=self.head
        if(head is not None):
            if(head.data == nw):
                self.head = head.next
                head = None
                return
        while(head is not None):
            if(head.data == nw):
                break
            prev = head
            head = head.next
        if(head == None):
            return
        prev.next = head.next
        head = None
    def count_occurrence(self, data):
        count = 0
        temp = self.head
        while temp:
            if temp.data == data:
                count += 1
            temp = temp.next
        return count
    def remove_duplicates(self):
        temp = self.head
        if temp is None:
            return
        while temp.next is not None:
            if temp.data == temp.next.data:
                new = temp.next.next
                temp.next = None
                temp.next = new
            else:
                temp = temp.next
    def reverse_iterative(self):
        prev = None
        current = self.head
        while(current is not None):
            next = current.next
            current.next = prev
            prev = current
            current = next
        self.head = prev
    def len_iterative(self):
        count = 0
        temp = self.head
        while temp:
            count += 1
            temp = temp.next
        return count
    def swap_nodes(self, key_1, key_2):
        if key_1 == key_2:
            return
        
        prev_1 = None
        curr_1 = self.head
        while curr_1 and curr_1.data != key_1:
            prev_1 = curr_1
            curr_1 = curr_1.next
        
        prev_2 = None
        curr_2 = self.head
        while curr_2 and curr_2.data != key_2:
            prev_2 = curr_2
            curr_2 = curr_2.next
        
        if not curr_1 or not curr_2:
            return
        
        if prev_1:
            prev_1.next = curr_2
        else:
            self.head = curr_2
        
        if prev_2:
            prev_2.next = curr_1
        else:
            self.head = curr_1
        
        curr_1.next, curr_2.next = curr_2.next, curr_1.next

L=Linked_list()
L.head = Node("a")
second = Node("b")
third = Node("c")
fourth = Node("d")
fifth = Node("e")
sixth = Node("f")
L.head.next = second
second.next = third
third.next = fourth
fourth.next = fifth
fifth.next = sixth
L.delnode("d")
L.insertbtw(second,"hi")
L.prepend(0)
L.append("z")
L.print_list()
print("Length of Linked List (iterative): ", L.len_iterative())
L.swap_nodes("b","f")
print("Linked List after swapping nodes:")
L.print_list()
'''

'''
21)Basic Queue Implementation
class Queue:
    def __init__(self):
        self.queue=list()
    def add(self,value):
        if value not in self.queue:
            self.queue.append(value)
            return True
        return False
    def remove(self):
        if len(self.queue)>0:
            return self.queue.pop()
        return False
    def enqueue(self,value):
        if value not in self.queue:
            self.queue.insert(0,value)
            return True
        return False
    def dequeue(self):
        if(len(self.queue))>0:
            return self.queue.pop(0)
        return False
    def front(self):
        if(len(self.queue))>0:
            return self.queue[0]
        return False
    def size(self):
        return len(self.queue)
    def print_queue(self):
        for i in range(len(self.queue)):
            print(self.queue[i],end="")
    def isempty(self):
        if(len(self.queue))>0:
            return False
        return True
    def reversequeue(queue):
        Stack = []
     
        while (queue):
            Stack.append(queue[0])
            queue.popleft()
     
        while (len(Stack) != 0):
            queue.append(Stack[-1])
            Stack.pop()

x=Queue()
x.add(1)
x.add(2)
x.add(3)
x.add(4)
x.add(5)
x.print_queue()
print("\n")
print(x.size())
print(x.isempty())
x.enqueue(6)
x.print_queue()
print("\n")
print(x.remove())
print("\n")
x.print_queue()
print("\n")
print(x.front())
print("\n")
x.print_queue()
'''


'''
22) All list operations
# Create a list of integers
numbers = [1, 2, 3, 4, 5]

# Use the append method to add an element to the end of the list
numbers.append(6)
print(numbers) # [1, 2, 3, 4, 5, 6]

# Use the insert method to add an element at a specific index
numbers.insert(2, 0)
print(numbers) # [1, 2, 0, 3, 4, 5, 6]

# Use the remove method to remove an element by value
numbers.remove(3)
print(numbers) # [1, 2, 0, 4, 5, 6]

# Use the pop method to remove and return the last element
last_element = numbers.pop()
print(last_element) # 6
print(numbers) # [1, 2, 0, 4, 5]

# Use the index method to find the index of a specific element
index = numbers.index(4)
print(index) # 3

# Use the count method to count the number of occurrences of an element
count = numbers.count(1)
print(count) # 1

# Use the sort method to sort the list in ascending order
numbers.sort()
print(numbers) # [0, 1, 2, 4, 5]

# Use the reverse method to reverse the order of the list
numbers.reverse()
print(numbers) # [5, 4, 2, 1, 0]

# Use the extend method to add multiple elements to the end of the list
numbers.extend([7, 8, 9])
print(numbers) # [5, 4, 2, 1, 0, 7, 8, 9]

# Use the copy method to create a copy of the list
new_numbers = numbers.copy()
print(new_numbers) # [5, 4, 2, 1, 0, 7, 8, 9]

# Use the clear method to remove all elements from the list
numbers.clear()
print(numbers) # []

# Use the min method to find the smallest element in the list
minimum = min(new_numbers)
print(minimum) # 0

# Use the max method to find the largest element in the list
maximum = max(new_numbers)
print(maximum) # 9

'''
