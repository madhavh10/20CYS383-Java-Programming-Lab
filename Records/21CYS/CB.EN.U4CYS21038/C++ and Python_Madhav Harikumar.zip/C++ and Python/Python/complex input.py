b=complex(input())
print(b)
