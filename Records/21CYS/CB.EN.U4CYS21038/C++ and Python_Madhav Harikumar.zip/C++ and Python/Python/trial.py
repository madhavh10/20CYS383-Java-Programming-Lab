def armstrong(a):
    temp=a
    sum=0
    r=0
    while(a>0):
       r=a%10
       sum+=r*r*r
       a//=10
    if(temp==sum):
        return True
    else:
        return False
a=map(int,input().split())
c=0
for i in a:
    if(armstrong(i)):
       c+=1
print(c)
