class individual:
    def __init__(self,character_name):
        self.character_name=character_name
        self.happy=True
    def get_character_name(self):
        return self.character_name
    def is_happy(self):
        return self.happy
    def switch_mood(self):
        if(self.happy==True):
            self.happy=False
        else:
            self.happy=True
    def speak(self):
        if(self.happy==True):
            return 'Hello, I am '+self.character_name
        else:
            return 'Go away!'
y=individual('Johny')
individual1=individual('Buster')
individual2=individual('tobias')
individual3=individual('Lucille')
print(y.is_happy())
print(y.switch_mood())
print(y.is_happy())
print(individual1.get_character_name())
print(individual1.speak())
print(individual2.get_character_name())
