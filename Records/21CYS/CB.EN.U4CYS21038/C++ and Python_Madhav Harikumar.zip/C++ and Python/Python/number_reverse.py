n=int(input())
a=str(n)
print(a[::-1])
