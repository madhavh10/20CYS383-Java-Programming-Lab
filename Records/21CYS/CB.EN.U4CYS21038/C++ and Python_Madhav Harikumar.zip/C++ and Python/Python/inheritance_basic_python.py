'''
Basic concept of inheritance
class A:
    def feature1(self):
        print("Feature 1 working")
    def feature2(self):
        print("Feature 2 working")

class B(A):
    def feature3(self):
        print("feature 1 working")
    def feature4(self):
        print("feature 2 working")

a1=A()
a1.feature1()
a1.feature2()

b1=B()
b1.feature1()
b1.feature2()

b1.feature3()
b1.feature4()
'''
'''
super() function
class Person():
    def __init__(self,fname,lname):
        self.firstname=fname
        self.lastname=lname
    def printname(self):
        print(self.firstname,self.lastname)
class Student(Person):
    def __init__(self,fname,lname):
        super().__init__(fname,lname)
x=Student("John","Thomas")
x.printname()
'''
