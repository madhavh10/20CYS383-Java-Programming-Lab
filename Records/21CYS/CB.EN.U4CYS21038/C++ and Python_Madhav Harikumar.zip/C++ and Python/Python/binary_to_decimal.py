x=input()
print(int(x,2))
