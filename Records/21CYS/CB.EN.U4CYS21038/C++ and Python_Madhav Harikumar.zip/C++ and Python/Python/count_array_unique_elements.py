import array
import operator
arr=array.array('i',[10,10,4,5,6,7,5,4,8])
L=arr.tolist()
L1=[]
x=0
for i in set(L):
    x=operator.countOf(L,i)
    print(i,"=",x)

