'''
Linked list using deque
from collections import deque
linked_list = deque()
linked_list.append(0)
print(type(linked_list)) #<class 'collections.deque'>
print(linked_list) #deque([0])
linked_list.appendleft(1)
print(linked_list) #deque([1, 0])
linked_list.pop()
print(linked_list) #deque([1]) last element is popped out
linked_list.append(2)
print(linked_list)
linked_list.append(3)
print(linked_list) #deque([1, 2, 3])
linked_list.popleft()
print(linked_list) #deque([2, 3])







Queue using deque
from collections import deque
queue = deque()
for i in range(0,5):
    queue.append(i)
print(queue) #deque([0, 1, 2, 3, 4])

    deque([0])
    deque([0, 1])
    deque([0, 1, 2])
    deque([0, 1, 2, 3])
    deque([0, 1, 2, 3, 4])

for i in range(len(queue)):
    queue.popleft()
    print(queue)

deque([1, 2, 3, 4])
deque([2, 3, 4])
deque([3, 4])
deque([4])
deque([])

'''
'''
from collections import deque
class Node:
    def __init__(self,data=None):
        self.data = data
        self.next = None
class Linked:
    def __init__(self):
        self.head = None
    def show(self):
        node = self.head
        while node is not None:
            print(node.data)
            node = node.next
    def add(self,new):
        new_node = Node(new)
        new_node.next = self.head
        self.head = new_node
        
a = Linked()
ele = Node("A")
a.head = ele
ele1 = Node("B")
a.head.next = ele1
a.add("YOO")
a.show()
'''
class Node:
    def __init__(self,data=None):
        self.data=data
        self.next=None

class Linked:
    def __init__(self,val):
        new_node = Node(val)
        self.head = new_node
        self.tail = new_node
        self.length = 1
    def print_list(self):
        temp=self.head
        while temp is not None:
            print(temp,end="->")
            tempp=temp.next
    def append(self,new):
        new_node = Node(new)
        if(self.length==0):
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        self.length = self.length + 1
    def preprend(self,new):
        new_node = Node(new)
        if(self.length==0):
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.tail = new_node
        self.length = self.length + 1
    def pop(self):
        if(self.length==0):
            print("Empty Linked list")
        else:
            x=self.data
            self = self.next
            print("Popped element is:",x)
            return self
c=Linked(10)
c.append(1)
c.append(2)
c.append(3)
c.append(4)
c.append(5)
c.append(6)
c.print_list()

        

