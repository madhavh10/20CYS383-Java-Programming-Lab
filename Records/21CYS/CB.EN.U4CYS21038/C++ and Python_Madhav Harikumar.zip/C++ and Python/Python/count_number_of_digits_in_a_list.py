L=[456,76,32,2345,643]
x=[]
for i in L:
    x.append(i[::-1])
print(x)
