for i in range(1,5):
    for j in range(i+1):
        print(i,end="")
    print("\n")