n=int(input())
for i in range(n):
    a,b=map(int,input().split())
    for i in range(a):
        for j in range(b):
            c,d=map(int,input().split())
        print(max(c,d))
