n=int(input())
c=0
for i in str(n):
    if(int(i)%2==0):
        c+=1
print("\nEven number of digits is:",c)

