import math as d
class Point:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def show(self):
        return (self.a,self.b)
    def move(self,a,b):
        self.a = self.a+a 
        self.b = self.b+b
    def dist(self,x):
        #print(x.a)
        f = d.sqrt(d.pow(x.a-self.a,2)+d.pow(x.b-self.b,2))
        print(f)
p1=Point(2,3)
p2=Point(3,3)
print(p1.show())
print(p2.show())
#p1.move(10,-10)
#print(p1.show())
#p1.dist(p2)
p1.dist(p2)
