'''
class A:
#@start-editable@

    def set_a(self,a):
        self.a=a
    def get_a(self):
        return self.a
    def __neg__(self):
        self.a= -1*(self.a)

#@end-editable@

ob=A() 
#set value
inp = int(input())
ob.set_a(inp)
#get value
ob.get_a();

#Calling operator overloaded function - to negate the value
-ob

#The value of a after calling operator overloading function - is
ob.get_a()
'''
import math

class Circle:
#@start-editable@

    def __init__(self,a):
        self.a=a
    def get_result__str__(self):
        return Circle(self.a)
    def area(self):
        return (math.pi * pow(self.a,2))
    def __add__(self,x):
        return Circle(self.a + x.a)
    def __sub__(self,x):
        return Circle(abs(x.a - self.a))
    def __mul__(self,x):
        return Circle(self.a * x.a)
    def __lt__(self,x):
        self.a < x.a
        
    


#@end-editable@
 
input1=int(input())
c1 = Circle(input1)
print(c1.get_result())
print(c1.area())

input2=int(input()) 
c2 = Circle(input2)
print(c2.get_result())
print(c1.area())
 
c3 = c1 + c2
print(c3.get_result())
 
c3 = c2 - c1
print(c3.get_result())
 
c4 = c1 * c2
print(c4.get_result())
 
c5 = c1 < c2
print(c5.get_result())
 
c5 = c2 < c1
print(c5.get_result())

