#x=20
try:
    print(x)
except:
    print("Something is not happening")
finally: #This means that even if try or except statement happens, the statement inside finally gets printed
    print("the try except is finished")

x= -1
if(x<0):
    #raise Exception("Sorry") #Raise will stop the running of the code and will show an error
    raise Exception("Sorry","yo","Bro")
'''
Why use Argument in Exceptions? 
Using arguments for Exceptions in Python is useful for the following reasons: 

It can be used to gain additional information about the error encountered.
 
As contents of an Argument can vary depending upon different types of Exceptions in Python, Variables can be supplied to the Exceptions to capture the essence of the encountered errors. Same error can occur of different causes, Arguments helps us identify the specific cause for an error using the except clause.
 
It can also be used to trap multiple exceptions, by using a variable to follow the tuple of Exceptions.
'''
