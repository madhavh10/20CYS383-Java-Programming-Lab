n=int(input())
for i in range(n):
    if(i%2==0):
        print("*+",*(i//2))
        
    else:
        for j in range(1,i+1):
            print(j*i,"\t",end="")
        print("\n")
